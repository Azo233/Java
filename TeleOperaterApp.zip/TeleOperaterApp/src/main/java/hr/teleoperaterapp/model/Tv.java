package hr.teleoperaterapp.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Andrija
 */
@Entity(name = "Tv")
public class Tv extends Entitet{
    
    
    private boolean SportskiKanali;
    private boolean FilmskiKanali;
    private int cijena;

    public boolean isSportskiKanali() {
        return SportskiKanali;
    }

    public void setSportskiKanali(boolean SportskiKanali) {
        this.SportskiKanali = SportskiKanali;
    }

    public boolean isFilmskiKanali() {
        return FilmskiKanali;
    }

    public void setFilmskiKanali(boolean FilmskiKanali) {
        this.FilmskiKanali = FilmskiKanali;
    }

    public int getCijena() {
        return cijena;
    }

    public void setCijena(int cijena) {
        this.cijena = cijena;
    }
    
    
}
